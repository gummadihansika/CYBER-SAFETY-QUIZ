# Cyber Safety Quiz

A local-first mini-project for testing password, phishing, and online safety awareness.

## Requirements
- Python 3.10+
- Core CLI/backend: Python standard library only
- Streamlit is required only for the optional web interface

## Run the Terminal CLI
```bash
python main.py
```

## Run the Streamlit Web UI
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
streamlit run app_streamlit.py
```

## Features
- Quiz scoring and saved attempts; JSON and CSV persistence
- SQLite mirror with category, participant, and timestamp indexes
- Thread and OS-level advisory locking, atomic file replacement
- Corruption recovery with timestamped `.bak` files and audit trail
- Search, summary analytics, threshold warnings, CSV import, and report exports
- Native Streamlit components only; no raw HTML or custom CSS

Data is stored in `data/`; generated reports are stored in `reports/`.


## Verification
Run the automated core checks from the project root:

```bash
python -m unittest discover -s tests -v
python -m compileall -q src main.py app_streamlit.py
```

The core test suite covers validation boundaries, quiz scoring and persistence,
empty analytics, missing/corrupt JSON recovery, SQLite indexes, literal keyword
search, duplicate IDs, row-by-row CSV import errors, and Markdown/CSV exports.
The web interface is optional; install `requirements.txt` before launching it.

## Rubric alignment
- **Architecture:** shared `src/` service layer is used by both CLI and Streamlit.
- **Data integrity:** JSON is canonical; JSON/CSV file writes use temporary files
  and atomic replacement; SQLite provides indexed lookup; audit events are timestamped.
- **Recovery:** malformed JSON is archived with a timestamped `.bak` suffix and
  the application initializes an empty register.
- **Input safety:** names, category values, answer indexes, scores, and durations
  are validated before saving; CSV import reports rejected row numbers.
- **Reporting:** executive totals, averages, category/status counts, warnings,
  and Markdown/CSV/audit exports are available.
- **Tests and delivery:** standard-library `unittest`, CI workflow, API reference,
  seed JSON/CSV datasets, and this run guide are included.

**Known limitation:** the JSON and CSV files are each replaced atomically, but
the pair plus SQLite are not a single cross-file transaction. If a process stops
between those writes, restart from the canonical JSON file to rebuild the mirrors.
