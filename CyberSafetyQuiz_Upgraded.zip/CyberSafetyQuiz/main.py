"""Launch the standard-library terminal application."""
from src.storage import Storage
from src.business_logic import QuizService
from src.ui import run_cli


def main() -> None:
    """Initialize persistence and run the CLI."""
    run_cli(QuizService(Storage()))


if __name__ == "__main__":
    main()
