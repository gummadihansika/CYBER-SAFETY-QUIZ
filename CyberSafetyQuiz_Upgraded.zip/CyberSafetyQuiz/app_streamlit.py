"""Native-component Streamlit web interface; backend is shared with the CLI."""
import streamlit as st
from src.storage import Storage
from src.business_logic import QuizService, QUESTIONS
from src.models import Category
from src.validators import validate_name
from src.exporters import export_markdown, export_csv, export_audit

st.set_page_config(page_title="Cyber Safety Quiz", page_icon="🛡️", layout="wide")
service = QuizService(Storage())

st.title("🛡️ Cyber Safety Quiz")
st.caption("Password • Phishing • Online Safety | Local-first learning and reporting")
page = st.sidebar.radio("Navigate", ["Take a quiz", "Records & search", "Executive summary", "Reports"])

if page == "Take a quiz":
    st.subheader("Knowledge check")
    participant = st.text_input("Participant name")
    category_label = st.selectbox("Quiz category", [c.value for c in Category])
    category = Category(category_label)
    questions = QUESTIONS[category]
    with st.form("quiz_form"):
        answers = []
        for i, (question, options, _) in enumerate(questions):
            answers.append(st.radio(question, options, index=None, key=f"q{i}"))
        submitted = st.form_submit_button("Submit quiz")
    if submitted:
        try:
            name = validate_name(participant)
            if any(answer is None for answer in answers):
                st.warning("Please answer every question before submitting.")
            else:
                indexes = [options.index(answer) for answer, (_, options, _) in zip(answers, questions)]
                record = service.conduct_quiz(name, category, indexes)
                st.success(f"Score: {record.score}/{record.total} ({record.percentage:.1f}%) — {record.status.value}")
                st.info("Review safe practices and try another category to strengthen awareness.")
        except ValueError as exc:
            st.error(str(exc))

elif page == "Records & search":
    st.subheader("Saved quiz records")
    col1, col2 = st.columns(2)
    keyword = col1.text_input("Search participant, ID, or notes")
    category = col2.selectbox("Category filter", ["All"] + [c.value for c in Category])
    rows = service.storage.search(keyword, "" if category == "All" else category)
    if rows:
        st.dataframe([r.to_dict() for r in rows], use_container_width=True, hide_index=True)
    else:
        st.info("No matching records.")

elif page == "Executive summary":
    summary = service.summary()
    a, b, c = st.columns(3)
    a.metric("Attempts", summary["total_attempts"])
    b.metric("Participants", summary["unique_participants"])
    c.metric("Average score", f"{summary['average_percentage']:.1f}%")
    st.subheader("Category totals")
    st.bar_chart(summary["category_counts"])
    st.subheader("Performance status")
    st.bar_chart(summary["status_counts"])
    st.subheader("Threshold warnings")
    warnings = service.warnings()
    if warnings:
        for warning in warnings:
            st.warning(warning)
    else:
        st.success("No warnings.")

else:
    st.subheader("Export reports")
    out = st.session_state.get("report_dir", "reports")
    if st.button("Generate Markdown, CSV, and audit log"):
        md = export_markdown(service, f"{out}/summary.md")
        csv_path = export_csv(service, f"{out}/records.csv")
        audit_path = export_audit(service.storage, f"{out}/audit_log.txt")
        st.success(f"Reports saved to {out}/")
        for path in (md, csv_path, audit_path):
            st.write(str(path))
    st.caption("Reports are saved locally in the project directory.")
