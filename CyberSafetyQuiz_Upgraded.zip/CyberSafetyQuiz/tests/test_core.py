"""Core validation, persistence, recovery, indexing, and logic tests."""
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from src.models import Category
from src.storage import Storage
from src.business_logic import QuizService
from src.validators import ValidationError, validate_name, validate_score, parse_int


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.storage = Storage(self.temp.name)
        self.service = QuizService(self.storage)

    def tearDown(self):
        self.temp.cleanup()

    def test_validation(self):
        self.assertEqual(validate_name("  Asha  Rao "), "Asha Rao")
        with self.assertRaises(ValidationError):
            validate_name("")
        self.assertEqual(validate_score(3, 3), (3, 3))
        with self.assertRaises(ValidationError):
            validate_score(4, 3)
        with self.assertRaises(ValidationError):
            parse_int("abc", 1, 5)

    def test_quiz_persists_and_summarizes(self):
        record = self.service.conduct_quiz("Asha Rao", Category.PASSWORD, [2, 2, 0], 45)
        self.assertEqual(record.score, 3)
        self.assertEqual(len(self.storage.read_all()), 1)
        self.assertEqual(self.service.summary()["total_attempts"], 1)

    def test_corrupt_json_recovery(self):
        self.storage.json_path.write_text("{broken", encoding="utf-8")
        recovered = Storage(self.temp.name)
        self.assertEqual(recovered.read_all(), [])
        self.assertTrue(list(Path(self.temp.name).glob("records.json.*.bak")))

    def test_sqlite_indexes_exist(self):
        with sqlite3.connect(self.storage.db_path) as conn:
            indexes = {row[1] for row in conn.execute("PRAGMA index_list(records)")}
        self.assertIn("idx_records_category", indexes)
        self.assertIn("idx_records_participant", indexes)

    def test_search_category(self):
        self.service.conduct_quiz("Ravi Kumar", Category.PHISHING, [2, 1, 2])
        self.assertEqual(len(self.storage.search(category="phishing")), 1)
        self.assertEqual(len(self.storage.search(keyword="Ravi")), 1)

    def test_boundary_answers_rejected(self):
        with self.assertRaises(ValueError):
            self.service.conduct_quiz("Asha", Category.PASSWORD, [4, 1, 1])

    def test_missing_file_initializes(self):
        self.assertEqual(self.storage.read_all(), [])
        self.assertTrue(self.storage.csv_path.exists())


    def test_empty_summary_has_safe_defaults(self):
        summary = self.service.summary()
        self.assertEqual(summary["total_attempts"], 0)
        self.assertEqual(summary["average_percentage"], 0.0)
        self.assertEqual(summary["records"], [])

    def test_csv_import_logs_bad_rows_and_keeps_valid_rows(self):
        import csv
        source = Path(self.temp.name) / "incoming.csv"
        with source.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=[
                "record_id", "participant", "category", "score", "total",
                "duration_seconds", "created_at", "notes"])
            writer.writeheader()
            writer.writerow({"record_id": "good1", "participant": "Maya Rao",
                             "category": "password", "score": 2, "total": 3,
                             "duration_seconds": 15, "notes": "practice"})
            writer.writerow({"record_id": "bad1", "participant": "",
                             "category": "unknown", "score": 9, "total": 3})
        added, errors = self.storage.import_csv(source)
        self.assertEqual(added, 1)
        self.assertEqual(len(errors), 1)
        self.assertIn("Row 3", errors[0])
        self.assertEqual(len(self.storage.read_all()), 1)

    def test_search_treats_percent_as_literal(self):
        self.service.conduct_quiz("Ravi Kumar", Category.PHISHING, [2, 1, 2])
        self.assertEqual(self.storage.search(keyword="%"), [])

    def test_add_record_rejects_duplicate_id(self):
        from src.models import QuizRecord, utc_now
        record = QuizRecord("sameid", "Asha", Category.PASSWORD, 2, 3, 10, utc_now())
        self.storage.add_record(record)
        with self.assertRaises(ValueError):
            self.storage.add_record(record)

    def test_export_markdown_and_csv(self):
        from src.exporters import export_markdown, export_csv
        self.service.conduct_quiz("Asha Rao", Category.PASSWORD, [2, 2, 0], 30)
        md = export_markdown(self.service, Path(self.temp.name) / "out" / "summary.md")
        csv_path = export_csv(self.service, Path(self.temp.name) / "out" / "records.csv")
        self.assertIn("Executive Summary", md.read_text(encoding="utf-8"))
        self.assertIn("record_id", csv_path.read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
