# API Reference

## Domain models — `src.models`
- `Category`: `PASSWORD`, `PHISHING`, `ONLINE_SAFETY`.
- `Status`: `EXCELLENT`, `PASS`, `NEEDS_PRACTICE`.
- `QuizRecord`: immutable attempt with participant, category, score, total, duration, timestamp, and notes.
- `QuizRecord.percentage`: score percentage rounded to two decimals.
- `QuizRecord.status`: excellent ≥85%, pass ≥60%, otherwise needs practice.

## Validation — `src.validators`
- `validate_name(value) -> str`: trims and validates participant names.
- `validate_score(score, total) -> tuple[int, int]`: enforces score and total bounds.
- `validate_duration(value) -> int`: validates duration in seconds.
- `validate_category(value) -> Category`: parses known category.
- `parse_int(value, minimum, maximum, label) -> int`: defensive bounded integer parser.
- `prompt_until_valid(prompt, parser, input_fn, output_fn) -> T`: retry loop.

## Persistence — `src.storage.Storage`
- `Storage(data_dir="data")`: initializes JSON, CSV, SQLite mirror, and audit log.
- `read_all() -> list[QuizRecord]`: reads canonical JSON data with recovery.
- `save_all(records) -> None`: atomic JSON/CSV writes and SQLite refresh.
- `search(keyword="", category="") -> list[QuizRecord]`: parameterized indexed SQLite search.
- `import_csv(source) -> tuple[int, list[str]]`: imports valid rows and returns row errors.
- `audit(action, detail) -> None`: appends timestamped audit event.

## Business logic — `src.business_logic.QuizService`
- `conduct_quiz(participant, category, answers, duration_seconds=0) -> QuizRecord`: validates, scores, saves, audits.
- `summary() -> dict`: attempts, participants, averages, category/status counts, low-score count, and records.
- `warnings() -> list[str]`: low-score, zero-duration, and short-quiz perfect-score flags.

## Exports — `src.exporters`
- `export_markdown(service, destination) -> Path`
- `export_csv(service, destination) -> Path`
- `export_audit(storage, destination) -> Path`

## Import facade — `src.importer`
- `import_dataset(storage, path) -> tuple[int, list[str]]`

## User interfaces
- `src.ui.run_cli(service)`: ANSI menu-driven terminal UI.
- `app_streamlit.py`: Streamlit web UI using the same backend services.
