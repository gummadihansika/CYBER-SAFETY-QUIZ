# Upgrade notes

## Improvements in this revision
- Added a storage-level append API with duplicate record-ID protection.
- Routed quiz persistence through the append API.
- Escaped `%`, `_`, and backslash in keyword searches so they are treated as
  literal characters rather than SQL `LIKE` wildcards.
- Removed a dynamic module import from search result reconstruction.
- Expanded core regression tests from 7 to 12, including CSV row errors,
  duplicate IDs, empty summary behavior, wildcard search, and report exports.
- Added verification commands, rubric mapping, and a documented cross-file
  consistency limitation.

## Verification
- `python -m unittest discover -s tests -v`: 12 tests passed.
- `python -m compileall -q src main.py app_streamlit.py`: passed.
