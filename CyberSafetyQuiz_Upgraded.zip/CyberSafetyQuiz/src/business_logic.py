"""Quiz content, scoring, records, and executive analytics."""
import uuid
from collections import Counter
from statistics import mean
from typing import Any

from .models import Category, QuizRecord, utc_now
from .validators import validate_name, validate_score, validate_duration


QUESTIONS: dict[Category, list[tuple[str, tuple[str, ...], int]]] = {
    Category.PASSWORD: [
        ("Which password is strongest?", ("password123", "Jashwanth2007", "T9!qL#2vR@8z", "12345678"), 2),
        ("What should you do with a password?", ("Reuse it everywhere", "Share it with friends", "Use a unique one per account", "Write it on a public note"), 2),
        ("Which is a useful extra protection?", ("Two-factor authentication", "Turning off updates", "Using your birthday", "Saving it in a public file"), 0),
    ],
    Category.PHISHING: [
        ("An email asks you to urgently verify your bank login via a link. Best action?", ("Click quickly", "Reply with your PIN", "Open the bank site independently", "Forward it to everyone"), 2),
        ("Which is a phishing warning sign?", ("Expected message from known contact", "Unexpected urgency and mismatched sender", "A saved contact", "A normal receipt"), 1),
        ("A suspicious attachment arrives. What should you do?", ("Open it", "Disable antivirus", "Verify with sender through another channel", "Send it to classmates"), 2),
    ],
    Category.ONLINE_SAFETY: [
        ("What should you share publicly?", ("Home address", "One-time password", "Only information you are comfortable making public", "Bank details"), 2),
        ("On public Wi-Fi, which is safest?", ("Access sensitive accounts without care", "Use secure sites and avoid sensitive tasks on unknown networks", "Share files with everyone", "Disable device lock"), 1),
        ("You receive an OTP you did not request. What next?", ("Share it with support", "Ignore and never share; secure the account if needed", "Post it online", "Reply to the sender"), 1),
    ],
}


class QuizService:
    """Application service layer; UI code should call these methods only."""

    def __init__(self, storage) -> None:
        self.storage = storage

    def conduct_quiz(self, participant: str, category: Category,
                     answers: list[int], duration_seconds: int = 0) -> QuizRecord:
        """Score submitted answer indexes and persist a completed attempt."""
        name = validate_name(participant)
        questions = QUESTIONS[category]
        if len(answers) != len(questions):
            raise ValueError("Answer count does not match the quiz.")
        if any(not isinstance(a, int) or a < 0 or a > 3 for a in answers):
            raise ValueError("Each answer must be an option index from 0 to 3.")
        score = sum(answer == question[2] for answer, question in zip(answers, questions))
        validate_score(score, len(questions))
        duration = validate_duration(duration_seconds)
        record = QuizRecord(uuid.uuid4().hex[:12], name, category, score, len(questions),
                            duration, utc_now())
        self.storage.add_record(record)
        self.storage.audit("QUIZ_COMPLETED", f"{record.record_id} {name} {category.value} {score}/{len(questions)}")
        return record

    def summary(self) -> dict[str, Any]:
        """Calculate totals, average, category counts, and status distribution."""
        records = self.storage.read_all()
        return {
            "total_attempts": len(records),
            "unique_participants": len({r.participant.casefold() for r in records}),
            "average_percentage": round(mean([r.percentage for r in records]), 2) if records else 0.0,
            "average_score": round(mean([r.score for r in records]), 2) if records else 0.0,
            "category_counts": dict(Counter(r.category.value for r in records)),
            "status_counts": dict(Counter(r.status.value for r in records)),
            "low_score_count": sum(r.percentage < 60 for r in records),
            "records": records,
        }

    def warnings(self) -> list[str]:
        """Return actionable threshold warnings for low or anomalous results."""
        warnings = []
        for record in self.storage.read_all():
            if record.percentage < 60:
                warnings.append(f"LOW SCORE: {record.participant} scored {record.percentage:.0f}% ({record.record_id}).")
            if record.duration_seconds == 0:
                warnings.append(f"ANOMALY: {record.record_id} has a zero-second duration.")
            if record.total <= 3 and record.score == record.total:
                warnings.append(f"BOUNDARY: {record.participant} achieved a perfect score on a short quiz.")
        return warnings
