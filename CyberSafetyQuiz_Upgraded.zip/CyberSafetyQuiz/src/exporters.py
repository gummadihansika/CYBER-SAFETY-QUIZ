"""Report exporters for Markdown, CSV, and audit text."""
import csv
from pathlib import Path
from .business_logic import QuizService


def export_markdown(service: QuizService, destination: str | Path) -> Path:
    """Write a human-readable executive summary in Markdown."""
    summary = service.summary()
    path = Path(destination)
    lines = ["# Cyber Safety Quiz — Executive Summary", "",
             f"- Total attempts: {summary['total_attempts']}",
             f"- Unique participants: {summary['unique_participants']}",
             f"- Average score: {summary['average_score']}",
             f"- Average percentage: {summary['average_percentage']}%", "",
             "## Category totals", ""]
    for category, count in sorted(summary["category_counts"].items()):
        lines.append(f"- {category}: {count}")
    lines += ["", "## Performance status", ""]
    for status, count in sorted(summary["status_counts"].items()):
        lines.append(f"- {status}: {count}")
    lines += ["", "## Records", "", "| Participant | Category | Score | % | Status |",
              "|---|---|---:|---:|---|"]
    for record in summary["records"]:
        lines.append(f"| {record.participant} | {record.category.value} | {record.score}/{record.total} | {record.percentage:.1f}% | {record.status.value} |")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    service.storage.audit("EXPORT_MARKDOWN", str(path))
    return path


def export_csv(service: QuizService, destination: str | Path) -> Path:
    """Export report records to standardized CSV."""
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["record_id", "participant", "category", "score", "total",
              "percentage", "status", "duration_seconds", "created_at", "notes"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(r.to_dict() for r in service.storage.read_all())
    service.storage.audit("EXPORT_CSV", str(path))
    return path


def export_audit(storage, destination: str | Path) -> Path:
    """Copy the audit log to a requested report destination."""
    path = Path(destination)
    path.parent.mkdir(parents=True, exist_ok=True)
    content = storage.audit_path.read_text(encoding="utf-8") if storage.audit_path.exists() else ""
    path.write_text(content, encoding="utf-8")
    storage.audit("EXPORT_AUDIT", str(path))
    return path
