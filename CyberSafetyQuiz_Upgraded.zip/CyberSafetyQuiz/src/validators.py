"""Defensive validation helpers shared by both user interfaces."""
import re
from typing import Callable, TypeVar

T = TypeVar("T")
NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9 ._'’-]{0,49}$")
ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,40}$")


class ValidationError(ValueError):
    """Raised when a domain value fails validation."""


def validate_name(value: str) -> str:
    """Validate and normalize a participant name."""
    clean = " ".join(value.strip().split())
    if not NAME_RE.fullmatch(clean):
        raise ValidationError("Use 1–50 letters, spaces, apostrophes, periods, or hyphens; begin with a letter.")
    return clean


def validate_score(score: int, total: int) -> tuple[int, int]:
    """Ensure quiz score and total are in a sensible range."""
    if isinstance(score, bool) or isinstance(total, bool):
        raise ValidationError("Score and total must be whole numbers.")
    if total < 1 or total > 100:
        raise ValidationError("Total must be between 1 and 100.")
    if score < 0 or score > total:
        raise ValidationError(f"Score must be between 0 and {total}.")
    return score, total


def validate_duration(value: int) -> int:
    """Validate duration in seconds."""
    if value < 0 or value > 86400:
        raise ValidationError("Duration must be between 0 and 86400 seconds.")
    return value


def validate_category(value: str):
    """Parse a category without accepting unknown values."""
    from .models import Category
    try:
        return Category(value.strip().lower())
    except (ValueError, AttributeError) as exc:
        raise ValidationError("Choose password, phishing, or online_safety.") from exc


def parse_int(value: str, minimum: int, maximum: int, label: str = "Value") -> int:
    """Parse an integer and enforce inclusive bounds."""
    try:
        parsed = int(value.strip())
    except (ValueError, AttributeError):
        raise ValidationError(f"{label} must be a whole number.")
    if not minimum <= parsed <= maximum:
        raise ValidationError(f"{label} must be between {minimum} and {maximum}.")
    return parsed


def prompt_until_valid(prompt: str, parser: Callable[[str], T], input_fn=input, output_fn=print) -> T:
    """Keep prompting until parser accepts input; never leak conversion errors."""
    while True:
        try:
            return parser(input_fn(prompt))
        except (ValidationError, ValueError, TypeError) as exc:
            output_fn(f"Invalid input: {exc}")
