"""ANSI terminal UI with validated prompts and paginated tables."""
import os
from pathlib import Path
from .models import Category
from .validators import prompt_until_valid, parse_int, validate_name, validate_category
from .business_logic import QUESTIONS
from .exporters import export_markdown, export_csv, export_audit

RESET = "\033[0m"
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BOLD = "\033[1m"


def color(text: str, code: str) -> str:
    """Apply ANSI color unless output is redirected."""
    return f"{code}{text}{RESET}" if os.isatty(1) else text


def paginated_table(rows: list, page_size: int = 10) -> None:
    """Print rows in fixed-width pages, waiting between pages."""
    if not rows:
        print("No records found.")
        return
    headers = ("ID", "Participant", "Category", "Score", "Percent", "Status")
    widths = (12, 20, 15, 7, 9, 17)
    print(" | ".join(h.ljust(w) for h, w in zip(headers, widths)))
    print("-+-".join("-" * w for w in widths))
    for start in range(0, len(rows), page_size):
        for r in rows[start:start + page_size]:
            values = (r.record_id, r.participant, r.category.value, f"{r.score}/{r.total}",
                      f"{r.percentage:.1f}%", r.status.value)
            print(" | ".join(str(v)[:w].ljust(w) for v, w in zip(values, widths)))
        if start + page_size < len(rows):
            response = input("-- More (Enter) / quit (q): ").strip().lower()
            if response == "q":
                break


def run_cli(service) -> None:
    """Run the main menu loop."""
    print(color("\n=== CYBER SAFETY QUIZ ===", CYAN + BOLD))
    print("Password • Phishing • Online Safety")
    while True:
        print("\n1. Take a quiz\n2. View records\n3. Search/filter\n4. Executive summary")
        print("5. Warnings\n6. Export reports\n7. Import CSV\n0. Exit")
        choice = input("Select: ").strip()
        if choice == "0":
            service.storage.audit("EXIT", "CLI closed")
            print("Goodbye!")
            return
        if choice == "1":
            try:
                name = validate_name(input("Participant name: "))
                category = validate_category(input("Category (password/phishing/online_safety): "))
                answers = []
                for number, (question, options, _) in enumerate(QUESTIONS[category], start=1):
                    print(f"\n{number}. {question}")
                    for i, option in enumerate(options, start=1):
                        print(f"  {i}. {option}")
                    answers.append(prompt_until_valid("Answer (1-4): ", lambda x: parse_int(x, 1, 4, "Answer")) - 1)
                record = service.conduct_quiz(name, category, answers)
                print(color(f"Result: {record.score}/{record.total} ({record.percentage:.1f}%) — {record.status.value}", GREEN))
            except ValueError as exc:
                print(color(f"Could not complete quiz: {exc}", RED))
        elif choice == "2":
            paginated_table(service.storage.read_all())
        elif choice == "3":
            keyword = input("Keyword (blank for all): ").strip()
            category = input("Category (blank for all): ").strip().lower()
            try:
                paginated_table(service.storage.search(keyword, category))
            except Exception as exc:
                print(f"Search failed: {exc}")
        elif choice == "4":
            summary = service.summary()
            for key, value in summary.items():
                if key != "records":
                    print(f"{key.replace('_', ' ').title()}: {value}")
        elif choice == "5":
            warnings = service.warnings()
            print("\n".join(warnings) if warnings else "No warnings.")
        elif choice == "6":
            out = Path("reports")
            print(export_markdown(service, out / "summary.md"))
            print(export_csv(service, out / "records.csv"))
            print(export_audit(service.storage, out / "audit_log.txt"))
        elif choice == "7":
            path = input("CSV file path: ").strip()
            try:
                added, errors = service.storage.import_csv(path)
                print(f"Imported {added} row(s); {len(errors)} rejected.")
                for error in errors:
                    print(f"  - {error}")
            except OSError as exc:
                print(f"Import failed: {exc}")
        else:
            print("Choose one of the listed options.")
