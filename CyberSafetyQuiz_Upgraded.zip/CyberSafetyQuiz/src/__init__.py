"""Cyber Safety Quiz application package."""
