"""Bulk CSV import facade."""
from pathlib import Path
from .storage import Storage


def import_dataset(storage: Storage, path: str | Path) -> tuple[int, list[str]]:
    """Import CSV records and return successful row count and errors."""
    return storage.import_csv(path)
