"""Typed domain models for Cyber Safety Quiz."""
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class Category(str, Enum):
    PASSWORD = "password"
    PHISHING = "phishing"
    ONLINE_SAFETY = "online_safety"


class Status(str, Enum):
    EXCELLENT = "excellent"
    PASS = "pass"
    NEEDS_PRACTICE = "needs_practice"


@dataclass(frozen=True)
class QuizRecord:
    """A completed quiz attempt."""
    record_id: str
    participant: str
    category: Category
    score: int
    total: int
    duration_seconds: int
    created_at: str
    notes: str = ""

    @property
    def percentage(self) -> float:
        """Return score as a percentage."""
        return round((self.score / self.total) * 100, 2) if self.total else 0.0

    @property
    def status(self) -> Status:
        """Classify performance using the project thresholds."""
        pct = self.percentage
        if pct >= 85:
            return Status.EXCELLENT
        if pct >= 60:
            return Status.PASS
        return Status.NEEDS_PRACTICE

    def to_dict(self) -> dict[str, Any]:
        """Serialize this record to a JSON-friendly mapping."""
        data = asdict(self)
        data["category"] = self.category.value
        data["percentage"] = self.percentage
        data["status"] = self.status.value
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "QuizRecord":
        """Build a record from persisted data, ignoring derived fields."""
        return cls(
            record_id=str(data["record_id"]),
            participant=str(data["participant"]),
            category=Category(data["category"]),
            score=int(data["score"]),
            total=int(data["total"]),
            duration_seconds=int(data.get("duration_seconds", 0)),
            created_at=str(data["created_at"]),
            notes=str(data.get("notes", "")),
        )


def utc_now() -> str:
    """Return a timezone-aware UTC timestamp."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
