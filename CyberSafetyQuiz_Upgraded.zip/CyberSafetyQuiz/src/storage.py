"""Thread- and process-safe persistence with atomic file replacement."""
import csv
import json
import os
import sqlite3
import tempfile
import threading
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from typing import Iterator

from .models import QuizRecord, Category

try:
    import fcntl  # Unix-like OS
except ImportError:  # pragma: no cover - Windows
    fcntl = None
try:
    import msvcrt  # Windows
except ImportError:  # pragma: no cover - Unix-like OS
    msvcrt = None


class Storage:
    """Manage JSON/CSV records, SQLite index, backups, and audit trail."""

    def __init__(self, data_dir: str | Path = "data") -> None:
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.json_path = self.data_dir / "records.json"
        self.csv_path = self.data_dir / "records.csv"
        self.db_path = self.data_dir / "records.sqlite3"
        self.audit_path = self.data_dir / "audit_log.txt"
        self.lock_path = self.data_dir / ".storage.lock"
        self._thread_lock = threading.RLock()
        self._initialize_db()
        self._load_or_recover()

    @contextmanager
    def _file_lock(self) -> Iterator[None]:
        """Acquire an in-process RLock and an OS-level advisory lock."""
        with self._thread_lock:
            with open(self.lock_path, "a+b") as lock_file:
                if os.name == "nt" and msvcrt:
                    lock_file.seek(0)
                    msvcrt.locking(lock_file.fileno(), msvcrt.LK_LOCK, 1)
                elif fcntl:
                    fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
                try:
                    yield
                finally:
                    if os.name == "nt" and msvcrt:
                        lock_file.seek(0)
                        msvcrt.locking(lock_file.fileno(), msvcrt.LK_UNLCK, 1)
                    elif fcntl:
                        fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)

    def _initialize_db(self) -> None:
        """Create SQLite mirror and indexed query columns."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS records (
                record_id TEXT PRIMARY KEY, participant TEXT NOT NULL,
                category TEXT NOT NULL, score INTEGER NOT NULL,
                total INTEGER NOT NULL, percentage REAL NOT NULL,
                status TEXT NOT NULL, duration_seconds INTEGER NOT NULL,
                created_at TEXT NOT NULL, notes TEXT NOT NULL)""")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_records_category ON records(category)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_records_participant ON records(participant)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_records_created_at ON records(created_at)")
            conn.commit()

    def _archive_corrupt(self, path: Path) -> None:
        """Move a corrupt file aside using a timestamped backup name."""
        if path.exists():
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
            path.replace(path.with_name(f"{path.name}.{stamp}.bak"))

    def _load_or_recover(self) -> None:
        """Recover missing or malformed JSON by archiving and rebuilding files."""
        try:
            with self.json_path.open("r", encoding="utf-8") as handle:
                raw = json.load(handle)
            records = [QuizRecord.from_dict(item) for item in raw]
        except FileNotFoundError:
            records = []
        except (json.JSONDecodeError, UnicodeDecodeError, TypeError, KeyError, ValueError):
            self._archive_corrupt(self.json_path)
            records = []
            self.audit("RECOVERY", "Archived invalid JSON and initialized a clean register")
        self.save_all(records)

    def audit(self, action: str, detail: str) -> None:
        """Append a timestamped audit event."""
        line = f"{datetime.now().astimezone().isoformat(timespec='seconds')} | {action} | {detail}\n"
        with self._file_lock():
            with self.audit_path.open("a", encoding="utf-8") as handle:
                handle.write(line)

    def read_all(self) -> list[QuizRecord]:
        """Read and validate records from the canonical JSON file."""
        with self._file_lock():
            try:
                with self.json_path.open("r", encoding="utf-8") as handle:
                    raw = json.load(handle)
                return [QuizRecord.from_dict(item) for item in raw]
            except FileNotFoundError:
                return []
            except (json.JSONDecodeError, TypeError, KeyError, ValueError):
                self._archive_corrupt(self.json_path)
                self.audit("RECOVERY", "Read-time JSON corruption archived")
                self.save_all([])
                return []

    def _atomic_write(self, path: Path, content: str) -> None:
        """Write text to a same-directory temporary file, then replace atomically."""
        fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
                handle.write(content)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, path)
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)

    def save_all(self, records: list[QuizRecord]) -> None:
        """Atomically persist records to JSON and CSV, then refresh SQLite."""
        with self._file_lock():
            json_text = json.dumps([r.to_dict() for r in records], indent=2, ensure_ascii=False)
            self._atomic_write(self.json_path, json_text + "\n")
            from io import StringIO
            buffer = StringIO()
            fields = ["record_id", "participant", "category", "score", "total",
                      "percentage", "status", "duration_seconds", "created_at", "notes"]
            writer = csv.DictWriter(buffer, fieldnames=fields)
            writer.writeheader()
            writer.writerows(r.to_dict() for r in records)
            self._atomic_write(self.csv_path, buffer.getvalue())
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("DELETE FROM records")
                conn.executemany("""INSERT INTO records VALUES
                    (:record_id,:participant,:category,:score,:total,:percentage,
                     :status,:duration_seconds,:created_at,:notes)""",
                    [r.to_dict() for r in records])
                conn.commit()

    def add_record(self, record: QuizRecord) -> None:
        """Append one record under the shared lock to avoid lost updates."""
        records = self.read_all()
        if any(existing.record_id == record.record_id for existing in records):
            raise ValueError(f"Duplicate record_id: {record.record_id}")
        records.append(record)
        self.save_all(records)

    def search(self, keyword: str = "", category: str = "") -> list[QuizRecord]:
        """Search records with SQLite indexes and safe parameterized SQL."""
        sql = "SELECT * FROM records WHERE 1=1"
        params: list[str] = []
        if category:
            sql += " AND category = ?"
            params.append(category)
        if keyword:
            sql += " AND (participant LIKE ? ESCAPE '\\' OR record_id LIKE ? ESCAPE '\\' OR notes LIKE ? ESCAPE '\\')"
            escaped = keyword.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            pattern = f"%{escaped}%"
            params.extend([pattern, pattern, pattern])
        sql += " ORDER BY created_at DESC"
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(sql, params).fetchall()
        return [QuizRecord(row[0], row[1], Category(row[2]),
                           row[3], row[4], row[7], row[8], row[9]) for row in rows]

    def import_csv(self, source: str | Path) -> tuple[int, list[str]]:
        """Import valid CSV rows; return count and row-numbered error messages."""
        import uuid
        from .models import Category
        from .validators import validate_name, validate_score, validate_duration
        accepted = self.read_all()
        seen = {r.record_id for r in accepted}
        errors: list[str] = []
        added = 0
        with open(source, newline="", encoding="utf-8-sig") as handle:
            for line_no, row in enumerate(csv.DictReader(handle), start=2):
                try:
                    rid = row.get("record_id", "").strip() or uuid.uuid4().hex[:12]
                    if rid in seen:
                        raise ValueError("duplicate record_id")
                    name = validate_name(row["participant"])
                    category = Category(row["category"].strip().lower())
                    total = int(row["total"])
                    score = int(row["score"])
                    validate_score(score, total)
                    duration = validate_duration(int(row.get("duration_seconds", 0)))
                    record = QuizRecord(rid, name, category, score, total, duration,
                                        row.get("created_at", "").strip() or datetime.now().astimezone().isoformat(),
                                        row.get("notes", "").strip())
                    accepted.append(record)
                    seen.add(rid)
                    added += 1
                except (KeyError, ValueError, TypeError) as exc:
                    errors.append(f"Row {line_no}: {exc}")
        self.save_all(accepted)
        self.audit("CSV_IMPORT", f"Added {added}; rejected {len(errors)} row(s)")
        return added, errors
